JSON_URL = 'http://www.utdallas.edu/~axn112530/cs6375/unsupervised/Tweets.json'
INIT_URL = 'http://www.utdallas.edu/~axn112530/cs6375/unsupervised/InitialSeeds.txt'
OUTPUT_PATH = './result.txt'